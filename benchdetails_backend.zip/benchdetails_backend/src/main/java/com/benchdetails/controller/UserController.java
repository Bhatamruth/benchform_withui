package com.benchdetails.controller;

import com.benchdetails.exception.UserNotFoundException;
import com.benchdetails.model.User;
import com.benchdetails.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("http://localhost:3000")
public class UserController {

    @Autowired
    private UserRepository userRepository;

    @PostMapping("/user")
    User newUser(@RequestBody User newUser) {
        // Handle the "reportingToBaseLocation" field
        String reportingToBaseLocation = newUser.getReportingToBaseLocation();
        if (reportingToBaseLocation == null || (!reportingToBaseLocation.equals("Yes") && !reportingToBaseLocation.equals("No"))) {
            // Handle the case where the value is neither "Yes" nor "No" (You can customize the validation logic)
            throw new IllegalArgumentException("Invalid reportingToBaseLocation value");
        }

        return userRepository.save(newUser);
    }

    @GetMapping("/users")
    List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @GetMapping("/user/{id}")
    User getUserById(@PathVariable Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new UserNotFoundException(id));
    }

    @PutMapping("/user/{id}")
    User updateUser(@RequestBody User newUser, @PathVariable Long id) {
        return userRepository.findById(id)
                .map(user -> {
                    user.setUsername(newUser.getUsername());
                    user.setName(newUser.getName());
                    user.setEmail(newUser.getEmail());
                    user.setB_location(newUser.getB_location());
                    user.setReportingToBaseLocation(newUser.getReportingToBaseLocation()); // Update reportingToBaseLocation
                    user.setCertifications(newUser.getCertifications());
                    return userRepository.save(user);
                }).orElseThrow(() -> new UserNotFoundException(id));
    }

    @DeleteMapping("/user/{id}")
    String deleteUser(@PathVariable Long id) {
        if (!userRepository.existsById(id)) {
            throw new UserNotFoundException(id);
        }
        userRepository.deleteById(id);
        return "User with id " + id + " has been deleted successfully.";
    }
}
