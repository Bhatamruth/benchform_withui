import axios from "axios";
import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./AddUser.css"; // Import your CSS file

export default function AddUser() {
  const navigate = useNavigate();

  const [user, setUser] = useState({
    name: "",
    username: "",
    email: "",
    b_location: "",
    reporting_to_base_location: "",
    certifications:""
  });

  const { name, username, email, b_location, reporting_to_base_location, certifications } = user;

  const onInputChange = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };
  
  const onSubmit = async (e) => {
    e.preventDefault();

    // Custom email validation
    const isValidEmail = email.includes("@") && email.endsWith("@capgemini.com");

    if (!isValidEmail) {
      alert("Invalid email format. Email should contain '@' and end with '@capgemini.com'");
      return; // Prevent form submission
    }

    // Validate base location
    const validLocations = [
      "Bangalore",
      "Bhubaneshwar",
      "Chennai",
      "Coimbatore",
      "Gandhinagar",
      "Gurgaon",
      "Hyderabad",
      "Kolkata",
      "Mumbai",
      "Noida",
      "Navi Mumbai",
      "Pune",
      "Salem",
      "Tiruchirapalli",
    ];

    if (!validLocations.includes(b_location)) {
      alert(
        "Invalid base location. Please select : Bangalore,Bhubaneshwar, Chennai, Coimbatore, Gandhinagar, Gurgaon, Hyderabad, Kolkata, Mumbai, Noida, Navi Mumbai, Pune, Salem, Tiruchirapalli"
      );
      return; // Prevent form submission
    }

    await axios.post("http://localhost:8080/user", user);
    navigate("/");
  };


  return (
    <div className="form-container">
      <div className="darkcyan-background">
        <h1 className="form-heading">Bench Data Form Template</h1>
        <p className="form-paragraph">Dear Team,</p>
        <p className="form-paragraph">
          Your latest information is crucial for us to provide you with the best support and stay connected. Please take a moment to update your details to ensure accuracy. Your contribution matters!
        </p>
        <p className="form-paragraph">Thank you for your cooperation.</p>
        <form onSubmit={(e) => onSubmit(e)}>
          <div className="form-row">
            <label htmlFor="name" className="form-label">
              Name <span className="required-field">*</span>
            </label>
            <input
              type="text"
              className="form-input"
              placeholder="Enter your name"
              name="name"
              value={name}
              required
              onChange={(e) => onInputChange(e)}
            />
          </div>
          <div className="form-row">
            <label htmlFor="username" className="form-label">
              Username <span className="required-field">*</span>
            </label>
            <input
              type="text"
              className="form-input"
              placeholder="Enter your username"
              name="username"
              value={username}
              required
              onChange={(e) => onInputChange(e)}
            />
          </div>
          <div className="form-row">
            <label htmlFor="email" className="form-label">
              E-mail <span className="required-field">*</span>
            </label>
            <input
              type="text"
              className="form-input"
              placeholder="Enter your e-mail address"
              name="email"
              value={email}
              required
              onChange={(e) => onInputChange(e)}
            />
          </div>
          <div className="form-row">
            <label htmlFor="b_location" className="form-label">
              Base Location <span className="required-field">*</span>
            </label>
            <p className="allowed-locations">
              Please select : Bangalore,Bhubaneshwar, Chennai, Coimbatore, Gandhinagar, Gurgaon, Hyderabad, Kolkata, Mumbai, Noida, Navi Mumbai, Pune, Salem, Tiruchirapalli
            </p>
            <input
              type="text"
              className="form-input"
              placeholder="Enter your base location"
              name="b_location"
              value={b_location}
              required
              onChange={(e) => onInputChange(e)}
            />
          </div>
          <div className="form-row">
            <label htmlFor="reporting_to_base_location" className="form-label">
              Are you currently reporting to your base location? <span className="required-field">*</span>
            </label>
            <div className="form-radio-group">
  <label>
    <input
      type="radio"
      name="reportingToBaseLocation"
      value="Yes" // Make sure this value matches what you expect
      onChange={(e) => onInputChange(e)}
      required
    />
    Yes
  </label>
  <label>
    <input
      type="radio"
      name="reportingToBaseLocation"
      value="No" // Make sure this value matches what you expect
      onChange={(e) => onInputChange(e)}
      required
    />
    No
  </label>
</div>
          </div>
          <div className="form-row">
            <label htmlFor="certifications" className="form-label">
            Certifications <span className="required-field">*</span>
            </label>
            <input
              type="text"
              className="form-input"
              placeholder="Enter Certification Achieved so far (comma separated)"
              name="certifications"
              value={certifications}
              required
              onChange={(e) => onInputChange(e)}
            />
          </div>
          <button type="submit" className="btn btn-outline-primary">
            Submit
          </button>
          <Link className="btn btn-outline-danger mx-2" to="/">
            Cancel
          </Link>
        </form>
      </div>
    </div>
  );
}
